from menu import MENU
from sys import exit

contacts = {
    'John': '780112333212',
    'Dima': '097651233321',
    'Jane': '312441231223',
    'Kolia': '31231234412',
    'Abraham': '441231231231',
    'Oleg': '13312344123'
}

def new_phone(nick,numbers):
    # add new username and phone number for him

    contacts[nick] = numbers
    print(f'We add new contact to your list -- name: {nick} with phone:{numbers}')
    

def update_phone(name,phone):
        # check name in list of numbers
    if name in contacts.keys(): 
        # upadate cell-phone in list 
        contacts[name] = phone
        print(f'Contact {name} updated number: {phone}')
    else:
        # if did't find send text with error 
        print("We hadn't find any contact with this nickname")

def show_phone(name):
    # show phone for this name 
    values_num = contacts[name]
    if name in contacts:
        # Output phone numbers for this person witth this nickname
        print(f'I found {name} with this phone number: {values_num}')

def show_all():
    # Output all information from list
    print('|{:^15}|{:^15}|'.format('nickname','phone_numbers'))
    for n,p in contacts.items():
        print('|{:^15}|{:^15}|'.format(n,p))

def menu():
    # if user forgot commands in this app, he can asked me about information how correct type information or commands
    print(MENU)
    #Bot said Welcom to User    
print("Welcome to the assistant bot!")
while True:
    # check have we some typed code in commandBot
    try:    

        #input needed command and information
        command = input('Enter a command:')
        parts = command.split()
        operation = parts[0]

        if operation == 'add' and len(parts) == 3:
            name = parts[1]
            phone = parts[2]

            new_phone(name,phone)

        elif operation == 'change' and len(parts) == 3:
            name = parts[1]
            phone = parts[2]

            update_phone(name,phone)

        elif  operation == 'phone' and len(parts) == 2:
            n = parts[1]
            show_phone(n)
        elif operation == 'all' and len(parts) == 1:
            show_all()

        elif operation == 'menu' and len(parts) == 1:
            menu()

        elif command.lower() == 'hello' and len(parts) == 1:
            print('How I can help you?')

        elif operation in ['close', 'exit'] and len(parts) == 1:
            print('Good bye!!')
            break
    # if the user has entered something incorrectly, informs him about it
    except Exception as e:
        print(f'Error: {e}')
