from datetime import datetime, timedelta, date
from collections import defaultdict
# import needed command
def get_birthdays_per_week(users):
    birthdays_per_week = defaultdict(list)
    today = datetime.today().date()

    for user in users:
        n = user["name"] # converted name to n
        b = user["birthday_day"].date() # converted birthday_day to b
        
        # this year
        coming_birthday = b.replace(year=today.year)

        # Check birthday day gone or coming
        if coming_birthday < today:
            coming_birthday = coming_birthday.replace(year=today.year + 1)

        delta_days = (coming_birthday - today).days

        # converted this to day of week 
        if delta_days < 7:
            day_of_week = (today + timedelta(days=delta_days)).strftime("%A")
            birthdays_per_week[day_of_week].append(n)
    return birthdays_per_week

users = [   # information about birthday days
    {'name': 'Dima','birthday_day': datetime(year=2004,month=8,day=23)},
    {'name': 'Kolia','birthday_day': datetime(year=1994,month=12,day=16)},
    {'name': 'Sania','birthday_day': datetime(year=2000,month=12,day=12)},
    {'name': 'Senia','birthday_day': datetime(year=1978,month=12,day=15)},
    {'name': 'Julia','birthday_day': datetime(year=1999,month=12,day=17)},
    {'name': 'Miki','birthday_day': datetime(year=2006,month=10,day=3)},
    {'name': 'Oden','birthday_day': datetime(year=1998,month=9,day=5)},
    {'name': 'Paran','birthday_day': datetime(year=2004,month=11,day=12)},
    {'name': 'Petro','birthday_day': datetime(year=2001,month=12,day=7)},
    {'name': 'Ivan','birthday_day': datetime(year=2005,month=12,day=19)},
    {'name': 'Franky','birthday_day': datetime(year=2000,month=8,day=10)},
    ]
res = get_birthdays_per_week(users)
# print birthday_day
for d, name in res.items():
    print(f"{d}: {', '.join(name)}")